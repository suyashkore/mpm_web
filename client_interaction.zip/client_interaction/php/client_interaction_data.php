<style>
    /* button tag */
    .btn_custom {
        background-color: #007BFF;
        color: white;
        padding: 4px 13px;
        border: none;
        border-radius: 5px;
        cursor: pointer;
        font-size: 13px;
        transition: background-color 0.3s ease;
    }

    .btn_custom:hover {
        background-color: #0056b3;
    }

    /* Modal background */
    .modal1 {
        display: none;
        position: fixed;
        z-index: 1060;
        left: 0;
        top: 0;
        width: 100%;
        height: 100%;
        background-color: rgba(0, 0, 0, 0.5);
        overflow: auto;
    }

    /* Modal content */
    .modal-content1 {
        background-color: white;
        margin: 15% auto;
        padding: 20px;
        border: 1px solid #888;
        border-radius: 17px;
        width: 45%;
        position: relative;
        text-align: center;
    }
</style>

<script>
 
</script>

<?php
include '../../config/config.php'; // Update this path based on your setup

if (isset($_POST['project_id']) && !empty($_POST['project_id'])) {
    $project_id = $_POST['project_id'];

    // SQL query to fetch data based on project_id
    $query = "SELECT `id`, `topic_id`, `project_id`, `topic_no`, `subject`, `initiated_from`, `initiated_on`, `criticality_level`, `inserted_on`, `inserted_by`, `status`, `closure_date`, `closed_by` FROM `client_intraction_header_all` WHERE `project_id` = ?";

    // Prepare and execute the query
    $stmt = $conn->prepare($query);
    $stmt->bind_param("s", $project_id);
    $stmt->execute();
    $result = $stmt->get_result();
    // <label for='Sort_By'>Sort By:</label>
    // <input type='text' id='Sort_By' onkeyup='Sort_ByTable()' name='Sort_By'>
// style='background-color: white;'
    // Check if there are results and display them
    if ($result->num_rows > 0) {
        echo "<div class='billing-milestone' id='billing_milestone' style='width:80%; margin:-450px auto; min-height:50vh;'>";
        echo "<div>
        <label for='search_by' style='font-weight: 900;color: #012970; '>Search By:</label>
        <input type='text' id='search_by' onkeyup='filterTable()' name='search_by'
         style='width:15%;padding:10px;border-radius:5px;border:1px solid #ccc;font-size:16px; '>
        </div> <br>";
        echo "<table id='data-table' class='table disabled-table'>";
        echo "<tr class='text-center'>
                <th>Sr.No</th>
                <th>Topic No</th>
                <th>Subject</th>
                <th>Date</th>
                <th>Status</th>
                <th>Critical Level</th>
                <th>Init Form</th>
                <th>Alerts</th>
                <th>Action</th>
              </tr>";
        $sr_no = 1;
        while ($row = $result->fetch_assoc()) {
            echo "<tr class='text-center'>";
            echo "<td>" . $sr_no++ . "</td>";
            echo "<td>" . $row['topic_no'] . "</td>";
            echo "<td>" . $row['subject'] . "</td>";
            echo "<td>" . $row['initiated_on'] . "</td>";
            echo "<td>" . $row['status'] . "</td>";
            echo "<td>" . $row['criticality_level'] . "</td>";
            echo "<td>" . $row['initiated_from'] . "</td>";
            echo "<td>" . $row['status'] . "</td>";
            echo "<td>
                <button class='btn_custom response-btn' style='background-color:white; color:Blue;' onclick='sendResponse(\"" . $row['topic_id'] . "\")'>Response</button>
                <button class='btn_custom response-btn' style='background-color:white; color:red;'>Close</button>
              </td>";
            echo "</tr>";
        }

        echo "</table>";
        echo "</div>";
    } else {
        echo "<script>
                document.getElementById('noDataModal').style.display = 'block';
              </script>";
    }
} else {
    echo "Invalid project ID.";
}
?>
