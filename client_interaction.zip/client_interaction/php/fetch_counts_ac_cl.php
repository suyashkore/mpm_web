<?php
include '../../config/config.php'; // Update this path based on your setup

// Prepare SQL queries
$activeTopicsQuery = "SELECT count(*) AS count FROM `client_intraction_header_all` WHERE `status`=1";
$closedTopicsQuery = "SELECT count(*) AS count FROM `client_intraction_header_all` WHERE `status`=2";

// Execute queries
$activeResult = $conn->query($activeTopicsQuery);
$closedResult = $conn->query($closedTopicsQuery);

// Fetch results
$activeCount = $activeResult->fetch_assoc()['count'];
$closedCount = $closedResult->fetch_assoc()['count'];

// Return as JSON
echo json_encode(array(
    'activeTopics' => $activeCount,
    'closedTopics' => $closedCount,
));

// Close connection
$conn->close();
?>
