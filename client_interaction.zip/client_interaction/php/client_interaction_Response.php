<?php
include '../../config/config.php'; // Update the path if necessary

if (isset($_POST['topic_id']) && !empty($_POST['topic_id'])) {
    $topic_no = $_POST['topic_id'];

    // SQL query to fetch data from pipeline_work_pointers_all based on project_id
    $query = "SELECT `id`, `topic_id`, `line_no`, `short_desc`, `detailed_desc`, `poke_from`, `poke_to`, `files`, `alert_no`, `inserted_on`, `discussion_date`, `deviation` FROM `client_intraction_transaction_all`
              WHERE `topic_id` = ?";

    $stmt = $conn->prepare($query);
    $stmt->bind_param("s", $topic_no);
    $stmt->execute();
    $result = $stmt->get_result();

    // Check if there are results and display them
    if ($result->num_rows > 0) {
        echo "<div class='billing-milestone' id='billing_milestone' style='width:80%; margin:300px auto; min-height:50vh;'>";
        echo "<table class='table disabled-table'>";
        echo "<tr class='text-center'>
                <th>Sr.NO</th>
                <th>Line NO</th>
                <th>Subject</th>
                <th>Details</th>
                <th>Date</th>
                <th>From</th>
                <th>File`s</th>
                <th>Alerts</th>
              </tr>";
        $sr_no = 1;
        while ($row = $result->fetch_assoc()) {
            echo "<tr class='text-center'>";
            echo "<td>" . $sr_no++ . "</td>";
            echo "<td>" . $row['line_no'] . "</td>";
            echo "<td>" . $row['short_desc'] . "</td>";
            
            // Extract the first 2-3 words from the detailed_desc
            $details = $row['detailed_desc'];
            $details_excerpt = implode(' ', array_slice(explode(' ', $details), 0, 3)); // Change 3 to the desired number of words
            
            echo "<td>
                    <span>$details_excerpt</span>... 
                    <a href='javascript:void(0)' class='read-more' onclick='showModal(" . json_encode($row) . ")'>Read More</a>
                  </td>";
            echo "<td>" . $row['discussion_date'] . "</td>";
            echo "<td>" . $row['poke_from'] . "</td>";
            echo "<td>" . $row['files'] . "</td>";
            echo "<td>" . $row['alert_no'] . "</td>";
            echo "</tr>";
        }

        echo "</table>";
        echo "</div>";

        // Modal for displaying detailed description
        echo "<div class='modal fade' id='detailsModal' tabindex='-1' role='dialog' aria-labelledby='modalLabel' aria-hidden='true'>";
        echo "<div class='modal-dialog' role='document'>";
        echo "<div class='modal-content'>";
        echo "<div class='modal-header'>";
        echo "<h5 class='modal-title' id='modalLabel'>Detailed Description</h5>";
        // echo "<span class='close' data-dismiss='modal'>&times;</span>";
        echo "</button>";
        echo "</div>";
        echo "<div class='modal-body' id='modal-body'>";
        echo "</div>";
        echo "<div class='modal-footer'>";
        echo "</div>";
        echo "</div>";
        echo "</div>";
        echo "</div>";
    } else {
        echo "No data found for the selected topic.";
    }
} else {
    echo "Invalid topic ID.";
}
?>